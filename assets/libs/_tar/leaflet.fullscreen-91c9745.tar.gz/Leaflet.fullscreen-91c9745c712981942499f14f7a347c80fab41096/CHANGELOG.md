## 1.0.2

* Invalidate map size on fullscreen toggle (#61)

## 1.0.1

* Fix package.json main
* Switch license to ISC

## 1.0.0

* pseudoFullscreen option
* Fix project structure and CSS

## 0.0.4

* Fix for multiple maps on one page
* Fix cancel full screen mode in Firefox (#29)
* Center icon on touch devices (#31)
* Fix IE8 support (#32)

## 0.0.3

* Added IE11 native fullscreen support (#27)

## 0.0.2

* Set appropriate title when fullscreen (#17)
* Replace on('load') with whenReady (#19)

## 0.0.1

* Project restructuring
* New icons, including retina icons

## 0.0.0

* Initial release
